const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "smartshop"
});

module.exports = db;

const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/smartshop");
