import React, { useState, useEffect } from "react";
import "./App.css";

function App() {
  const [count, setCount] = useState(0);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    fetch("http://localhost:5000/api/clicks")
      .then(res => res.json())
      .then(data => setCount(data.count));
  }, []);

  const handleClick = () => {
    fetch("http://localhost:5000/api/clicks", { method: "POST" })
      .then(res => res.json())
      .then(data => {
        setCount(data.count);
        setAnimate(true);
        setTimeout(() => setAnimate(false), 500); 
      });
  };

  return (
    <div className="container">
      <h1 className={animate ? "bounce" : ""}>React Click Counter</h1>
      <p className={animate ? "fade" : ""}>You clicked {count} times</p>
      <button onClick={handleClick} className="animated-btn">
        Click Me!
      </button>
    </div>
  );
}

export default App;
