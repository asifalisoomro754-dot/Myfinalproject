import express from "express";
import mongoose from "mongoose";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/reactClicksDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log("MongoDB connected"))
.catch((err) => console.log(err));

const clickSchema = new mongoose.Schema({
  count: { type: Number, default: 0 },
});

const Click = mongoose.model("Click", clickSchema);


app.get("/api/clicks", async (req, res) => {
  let click = await Click.findOne();
  if (!click) {
    click = new Click();
    await click.save();
  }
  res.json(click);
});


app.post("/api/clicks", async (req, res) => {
  let click = await Click.findOne();
  if (!click) {
    click = new Click();
  }
  click.count += 1;
  await click.save();
  res.json(click);
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
