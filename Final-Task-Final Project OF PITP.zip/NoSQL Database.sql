// Reviews Collection
{
  productId: 1,
  userName: "Alex",
  rating: 5,
  comment: "Great product!",
  createdAt: new Date()
}

// Reviews Collection
{
  productId: 1,
  userName: "Alex",
  rating: 5,
  comment: "Great product!",
  createdAt: new Date()
}

// Activity Logs
{
  userId: 12,
  action: "Login",
  timestamp: new Date()
}

