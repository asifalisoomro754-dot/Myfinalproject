
const links = document.querySelectorAll('nav a');
links.forEach(link => {
  if(link.href === window.location.href){
    link.style.color = '#ffdd59';
  }
});


const contactForm = document.querySelector('form');
if(contactForm){
  contactForm.addEventListener('submit', function(e){
    e.preventDefault();
    alert('Thank you for contacting us! We will get back to you soon.');
    contactForm.reset();
  });
}

const scrollBtn = document.createElement('button');
scrollBtn.textContent = '⬆';
scrollBtn.id = 'scrollBtn';
document.body.appendChild(scrollBtn);

scrollBtn.style.position = 'fixed';
scrollBtn.style.bottom = '20px';
scrollBtn.style.right = '20px';
scrollBtn.style.padding = '0.8rem';
scrollBtn.style.fontSize = '1.2rem';
scrollBtn.style.border = 'none';
scrollBtn.style.borderRadius = '50%';
scrollBtn.style.backgroundColor = '#1e3c72';
scrollBtn.style.color = 'white';
scrollBtn.style.cursor = 'pointer';
scrollBtn.style.display = 'none';
scrollBtn.style.zIndex = '1000';

window.addEventListener('scroll', () => {
  if(window.scrollY > 300){
    scrollBtn.style.display = 'block';
  } else {
    scrollBtn.style.display = 'none';
  }
});

scrollBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
